from django.apps import AppConfig


class DjAnsiConfig(AppConfig):
    name = 'dj_ansible'
