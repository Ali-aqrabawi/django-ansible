class DjangoAnsibleError(Exception):
    pass